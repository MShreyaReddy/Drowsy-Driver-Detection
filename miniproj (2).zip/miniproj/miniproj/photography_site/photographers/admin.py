from django.contrib import admin

# Register your models here.
from photographers.models import Contact,Photographer,Cuslogin
# Register your models here.
admin.site.register(Contact)
admin.site.register(Photographer)
admin.site.register(Cuslogin)